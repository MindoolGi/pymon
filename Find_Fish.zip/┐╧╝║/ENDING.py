import tkinter
import sys
def start_story():
    main_menu_frame.pack_forget()  # 메인 메뉴 숨기기
    start_frame.pack()  # 시작 스토리 프레임 보이기

#
def start_story2(): # 스토리 두번째 화면
    start_frame.pack_forget()
    start_frame2.pack()
    
def start_story3(): # 스토리 세번째 화면
    start_frame2.pack_forget()
    start_frame3.pack()
    
def start_story4(): # 스토리 네번째 화면
    start_frame3.pack_forget()
    start_frame4.pack()
    
def ggwp():
    sys.exit()
    
root = tkinter.Tk()
root.title("GAME")

root.geometry("800x600")
root.resizable(False,False)

main_menu_frame = tkinter.Frame(root)
main_menu_frame.pack()

# 메인 메뉴 이미지 로드
main_menu_img = tkinter.PhotoImage(file="END1.png")
main_menu_label = tkinter.Label(main_menu_frame, image=main_menu_img)
main_menu_label.pack()

next0_button = tkinter.PhotoImage(file="다음.png")
start_button = tkinter.Button(main_menu_frame, image= next0_button, command=start_story, bd = 0, highlightthickness=0)
start_button.pack()
start_button.place(x=600,y=400)

# 시작 스토리1
start_frame = tkinter.Frame(root)
start_frame.pack()

# 시작 스토리1 이미지 로드
start_img = tkinter.PhotoImage(file="END2.png")
start_label = tkinter.Label(start_frame, image = start_img)
start_label.pack()

# 스토리 끝내기1 버튼
next_button = tkinter.PhotoImage(file="다음.png")
story_button = tkinter.Button(start_frame, image = next_button, command=start_story2, bd = 0, highlightthickness=0)
story_button.pack()
story_button.place(x=600,y=400)

# --------------------------------------------------------------------------------------------------

# 시작 스토리2
start_frame2 = tkinter.Frame(root)
start_frame2.pack()

# 시작 스토리2 이미지 로드
start2_img = tkinter.PhotoImage(file="END3.png")
start2_label = tkinter.Label(start_frame2, image = start2_img)
start2_label.pack()

# 스토리 끝내기2 버튼
story2_button = tkinter.Button(start_frame2, image = next_button , command=start_story3, bd = 0, highlightthickness=0)
story2_button.pack()
story2_button.place(x=600,y=400)

# --------------------------------------------------------------------------------------------------

# 시작 스토리3
start_frame3 = tkinter.Frame(root)
start_frame3.pack()

# 시작 스토리3 이미지 로드
start3_img = tkinter.PhotoImage(file="END4.png")
start3_label = tkinter.Label(start_frame3, image = start3_img)
start3_label.pack()

# 스토리 끝내기3 버튼
story3_button = tkinter.Button(start_frame3, image = next_button, command=start_story4, bd = 0, highlightthickness=0)
story3_button.pack()
story3_button.place(x=600,y=400)

# --------------------------------------------------------------------------------------------------

# 시작 스토리4
start_frame4 = tkinter.Frame(root)
start_frame4.pack()

# 시작 스토리4 이미지 로드
start4_img = tkinter.PhotoImage(file="ENDGG.png")
start4_label = tkinter.Label(start_frame4, image = start4_img)
start4_label.pack()

# 스토리 끝내기4 버튼
story4_button = tkinter.Button(start_frame4, image = next_button, command=ggwp, bd = 0, highlightthickness=0)
story4_button.pack()
story4_button.place(x=600,y=400)



root.mainloop()