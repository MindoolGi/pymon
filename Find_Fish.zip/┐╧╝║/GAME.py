import tkinter
import subprocess
import tkinter.messagebox
import sys
from tkinter import simpledialog
from tkinter import PhotoImage, messagebox
import random
sys.setrecursionlimit(10**7) # 재귀 깊이 제한범위 확장
FNT = ("Times New Roman", 24)

# play 버튼을 누르면 시작되는 것 / 스토리 첫번째 화면
def start_story():
    main_menu_frame.pack_forget()  # 메인 메뉴 숨기기
    start_frame.pack()  # 시작 스토리 프레임 보이기

#
def start_story2(): # 스토리 두번째 화면
    start_frame.pack_forget()
    start_frame2.pack()
    
def start_story3(): # 스토리 세번째 화면
    start_frame2.pack_forget()
    start_frame3.pack()
    
def start_story4(): # 스토리 네번째 화면
    start_frame3.pack_forget()
    start_frame4.pack()
    
def start_story5():
    start_frame4.pack_forget()
    start_frame5.pack()
    
def start_story6():
    start_frame5.pack_forget()
    start_frame6.pack()

def world_map(): # 스토리 네번째 화면 후 월드맵 이동
    start_frame6.pack_forget()
    worldmap_frame.pack()
    
def start_realgame():
    start_frame4.pack_forget()
    worldmap_frame.pack_forget() # 시작 스토리 프레임 숨기기
    game_frame.pack() # 게임 프레임 보이기
    main_proc()
    
def start_realgame2(): # 기존 game_frame 맵을 불러오는데 바로 switch_maps를 통해 다른 맵 표시
    worldmap_frame.pack_forget() 
    game_frame.pack() 
    switch_maps("stage2.png")
    main_proc2()
    
# def boss_ending():
    
    
def switch_screen_inventory():
    game_frame.pack_forget()
    inventory_frame.pack()
    
def switch_stage1():
    if mx == 4 and my == 4:
        game_frame.pack_forget()
        worldmap_frame.pack()
            
    
key = ""
def key_down(e):
    global key
    key = e.keysym
    if key == "i":
        switch_screen_inventory()
    elif key == "m":
        switch_maps()

def key_up(e):
    global key
    key = ""

     
def stageclear1(): # 스테이지 1을 끝내면 스테이지 2 버튼 나오게 설정
    s2 = tkinter.PhotoImage(file="stage2b.png")
    stage2_button = tkinter.Button(worldmap_frame, image= s2, command=start_realgame2 , bd = 0, highlightthickness=0)
    stage2_button.image = s2 
    stage2_button.pack()
    stage2_button.place(x=650,y=550)
       
def last_dance():
    openendingpy()
    
def openendingpy():
    subprocess.Popen(["python","ENDING.py"])

    
    

def stageclear2():
    s3 = tkinter.PhotoImage(file="boss.png")
    stage2_button = tkinter.Button(worldmap_frame, image= s3, command = last_dance,bd = 0, highlightthickness=0)
    stage2_button.image = s3
    stage2_button.pack()
    stage2_button.place(x=750,y=350)   

def stage1_clear():
    game_frame.pack_forget()
    worldmap_frame.pack()

def switch_maps(new_map):
    global maps
    maps = [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,1,1,1,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,1,1,0,0,0,0,0,1,1,0,0,0,0,0,0,0,1,1,1,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,1,1,1,0,0,0,0,1,1,0,0,0,0,0,1,1,0,1,0,0,1,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,1,1,0,0,0,0,1,1,1,1,1,1,1,0,0,1,0,0,1,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,1,0,0,0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,1,1,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,1,1,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0,1,1,0,0,0,0,0,1,1,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,1,1,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
    ]
    
    game_frame = tkinter.Frame(root)
    canvas = tkinter.Canvas(game_frame, width=1500, height=900, bg="white")
    canvas.pack()

    game2_image = tkinter.PhotoImage(file="stage2.png")
    canvas.create_image(0,0,anchor=tkinter.NW, image=game2_image)
    
    for y in range(30):
        for x in range(50):
            if maps[y][x] == 1:
                canvas.create_rectangle(x*30, y*30, x*30+30, y*30+30, fill="gray")
                
mx = 1
my = 1



countki = 0

def main_proc(): # 스테이지 1 작동 / 여기에서 몬스터의 위치를 if로 지정하고, 그 위치에 다다르면 if문을 실행하여 몬스터와의 전투 실행 가능
    global mx, my, event_triggered, countki
    
    
    if key == "Up" and maps[my-1][mx] == 0:
        my = my - 1
    if key == "Down" and maps[my+1][mx] == 0:
        my = my + 1
    if key == "Left" and maps[my][mx-1] == 0:
        mx = mx - 1
    if key == "Right" and maps[my][mx+1] == 0:
        mx = mx + 1
    canvas.coords("MYCHR", mx*30+15, my*30+15)
    
    if (mx == 22 and my == 14) or (mx == 23 and my == 14):
        tkinter.messagebox.showinfo("알림", "여기에서 고양이를 키우는 사람이 하나 있다 했지...")
        event_triggered = True
        if event_triggered:
            return main_proc()
        
    
        
    # 전투화면 전환
    if (mx == 0 and my == 0):
        event_triggered = True
        if event_triggered:
            return main_proc()
        
    # 탈출구 설정, stage1_clear 함수 실행 시
    if (mx == 3 and my == 21) or (mx == 4 and my == 21) or (mx == 4 and my == 22) or (mx == 3 and my == 22):
        answer = simpledialog.askstring("결계 해제", "정답은 무엇인가?")
        if answer:
            if answer.lower() == "시간":
                tkinter.messagebox.showinfo("정답", "오른쪽으로 가는 결계가 해제되었습니다.")
                stageclear1() # 스테이지2 버튼이 나오게 하는 함수, 98번째 줄
                stage1_clear() # 게임을 끝내면 월드맵으로 돌아가기, 194번째 줄
                mx =  5
                my = 23
                event_triggered = True
                if event_triggered:
                    return main_proc()
                
            else:
                tkinter.messagebox.showinfo("오답", f"{answer}?? 틀렸다. 처음으로 되돌아가라!")
                game_frame.pack_forget()
                worldmap_frame.pack()
                mx = 1
                my = 1
                return
                # 처음으로 되돌아가기 ㅋ

    # 대화 실행 stage1_clear 함수 실행 시
    if (mx == 48 and my == 1) or (mx == 48 and my == 2):
        tkinter.messagebox.showinfo("NPC1", "내가 문제 하나를 내지. '이것'은 사람마다 다르게 느껴진다. 또한, '이것'은 돈이나 그 어떤 것으로도 살 수 없고, 만약 '이것'을 살 수 있더라면 온 세상의 사람들이 살 것이다. 답이 어딘가 쓸모 있을걸세~")
        mx = 45
        my = 3
        event_triggered = True
        if event_triggered:
                return main_proc()
        
    # 대화 실행 stage1_clear 함수 실행 시
    if (mx == 48 and my == 10) or (mx == 48 and my == 11):
        tkinter.messagebox.showinfo("NPC2", "어 고양이다! 우리동네에 고양이는 하나밖에 없어서 얼굴을 아는데.... 너는 처음보네")
        mx = 45
        my = 9
        event_triggered = True
        if event_triggered:
                return main_proc()
        
    # 대화 실행 stage1_clear 함수 실행 시
    if (mx == 37 and my == 10) or (mx == 36 and my == 10):
        tkinter.messagebox.showinfo("NPC3", "초록머리 청년이 키우는 고양이잖아? 안녕~... 아.. 자세히보니 다르게 생겼네.. 넌 누구니?")
        mx = 40
        my = 11
        event_triggered = True
        if event_triggered:
                return main_proc()
 
    # 대화 실행 stage1_clear 함수 실행 시
    if (mx == 45 and my == 27) or (mx == 45 and my == 28):
        x = 10
        answer2 = simpledialog.askstring("UpDownGame", "1부터 45까지의 숫자 중 랜덤으로 맞춰봐")
        if answer2:
                if answer2.lower() == str(x) :
                    tkinter.messagebox.showinfo("정답", "좋았어 이 번호를 넣어서 로또나 하나 사러 가야겠다.")
                    stage1_clear()# 게임을 끝내면 월드맵으로 돌아가기, 194번째 줄
                    stageclear2() # boss 버튼이 나오게 하는 함수, 98번째 줄b
                    mx =  5
                    my = 23
                    event_triggered = True
                    if event_triggered:
                        return
                if int(answer2) < x :
                    countki = countki + 1
                    ki = 3 - countki
                    tkinter.messagebox.showinfo("알림", f"{answer2}?? 아니야. UP. 기회는 {ki}번 남았다.")
                    event_triggered = True
                    if event_triggered:
                        return main_proc()
                    mx = 44
                    my = 24
                    return main_proc()
                if int(answer2) > x :
                    countki = countki + 1
                    ki = 3 - countki
                    tkinter.messagebox.showinfo("알림", f"{answer2}?? 아니야. DOWN. 기회는 {ki}번 남았다.")
                    event_triggered = True
                    if event_triggered:
                        return main_proc()
                    mx = 44
                    my = 24
                    return main_proc()
                    
                if countki >= 2 :
                    tkinter.messagebox.showinfo("오답", "운이 나쁘군, 다시 찾아오도록.")
                    game_frame.pack_forget()
                    worldmap_frame.pack()
                    mx = 1
                    my = 1
                    countki = 0
                    return
                # 처음으로 되돌아가기 ㅋ
                
                else : 
                    countki = countki + 1
                    ki = 3 - countki
                    tkinter.messagebox.showinfo("오답", f"{answer2}?? 아니야. 기회는 {ki}번 남았다.")
                    event_triggered = True
                    if event_triggered:
                        return main_proc()
                    mx = 44
                    my = 24
                    return main_proc()
            
    
        
    root.after(200, main_proc)
    
def main_proc2(): # 스테이지 2 작동 / 여기에서 몬스터의 위치를 if로 지정하고, 그 위치에 다다르면 if문을 실행하여 몬스터와의 전투 실행 가능
    global mx, my, event_triggered
    
    
    if key == "Up" and maps[my-1][mx] == 0:
        my = my - 2
    if key == "Down" and maps[my+1][mx] == 0:
        my = my + 2
    if key == "Left" and maps[my][mx-1] == 0:
        mx = mx - 2
    if key == "Right" and maps[my][mx+1] == 0:
        mx = mx + 2
    canvas.coords("MYCHR", mx*30+15, my*30+15)
    
    # 탈출구 설정, stage1_clear 함수 실행 시
    if (mx == 2 and my == 2) or (mx == 48 and my == 1) or (mx == 48 and my == 3):
        canvas.delete()
        
    root.after(200, main_proc)



root = tkinter.Tk()
root.title("GAME")
root.bind("<KeyPress>",key_down)
root.bind("<KeyRelease>",key_up)

root.geometry("1500x900")
root.resizable(False,False)

# 돈의 초깃값
initial_money = 200
player_money_var = tkinter.IntVar()
player_money_var.set(initial_money)

# 메인 메뉴 프레임
main_menu_frame = tkinter.Frame(root)
main_menu_frame.pack()

# 메인 메뉴 이미지 로드
main_menu_img = tkinter.PhotoImage(file="lobby.png")
main_menu_label = tkinter.Label(main_menu_frame, image=main_menu_img)
main_menu_label.pack()

# 시작 버튼
button_image = tkinter.PhotoImage(file="play.png")
start_button = tkinter.Button(main_menu_frame, image= button_image, command=start_story, bd = 0, highlightthickness=0)
start_button.pack()
start_button.place(x=550,y=750)

# ------------------------------------------------------------------------------------------------------

# 시작 스토리1
start_frame = tkinter.Frame(root)
start_frame.pack()

# 시작 스토리1 이미지 로드
start_img = tkinter.PhotoImage(file="1story.png")
start_label = tkinter.Label(start_frame, image = start_img)
start_label.pack()

# 스토리 끝내기1 버튼
next_button = tkinter.PhotoImage(file="다음.png")
story_button = tkinter.Button(start_frame, image = next_button, command=start_story2, bd = 0, highlightthickness=0)
story_button.pack()
story_button.place(x=1200,y=800)

# --------------------------------------------------------------------------------------------------

# 시작 스토리2
start_frame2 = tkinter.Frame(root)
start_frame2.pack()

# 시작 스토리2 이미지 로드
start2_img = tkinter.PhotoImage(file="1-1.png")
start2_label = tkinter.Label(start_frame2, image = start2_img)
start2_label.pack()

# 스토리 끝내기2 버튼
story2_button = tkinter.Button(start_frame2, image = next_button , command=start_story3, bd = 0, highlightthickness=0)
story2_button.pack()
story2_button.place(x=1200,y=800)

# --------------------------------------------------------------------------------------------------

# 시작 스토리3
start_frame3 = tkinter.Frame(root)
start_frame3.pack()

# 시작 스토리3 이미지 로드
start3_img = tkinter.PhotoImage(file="1-2.png")
start3_label = tkinter.Label(start_frame3, image = start3_img)
start3_label.pack()

# 스토리 끝내기3 버튼
story3_button = tkinter.Button(start_frame3, image = next_button, command=start_story4, bd = 0, highlightthickness=0)
story3_button.pack()
story3_button.place(x=1200,y=800)

# --------------------------------------------------------------------------------------------------

# 시작 스토리4
start_frame4 = tkinter.Frame(root)
start_frame4.pack()

# 시작 스토리4 이미지 로드
start4_img = tkinter.PhotoImage(file="1-3.png")
start4_label = tkinter.Label(start_frame4, image = start4_img)
start4_label.pack()

# 스토리 끝내기4 버튼
story4_button = tkinter.Button(start_frame4,image = next_button, command=start_story5, bd = 0, highlightthickness=0)
story4_button.pack()
story4_button.place(x=1200,y=800)

# --------------------------------------------------------------------------------------------------

# 시작 스토리5
start_frame5 = tkinter.Frame(root)
start_frame5.pack()

# 시작 스토리5 이미지 로드
start5_img = tkinter.PhotoImage(file="1-4.png")
start5_label = tkinter.Label(start_frame5, image = start5_img)
start5_label.pack()

# 스토리 끝내기5 버튼
story5_button = tkinter.Button(start_frame5, image = next_button, command=start_story6, bd = 0, highlightthickness=0)
story5_button.pack()
story5_button.place(x=1200,y=800)

# --------------------------------------------------------------------------------------------------

# 시작 스토리6
start_frame6 = tkinter.Frame(root)
start_frame6.pack()

# 시작 스토리5 이미지 로드
start6_img = tkinter.PhotoImage(file="2story.png")
start6_label = tkinter.Label(start_frame6, image = start6_img)
start6_label.pack()

# 스토리 끝내기5 버튼
story6_button = tkinter.Button(start_frame6, image = next_button, command=world_map, bd = 0, highlightthickness=0)
story6_button.pack()
story6_button.place(x=1200,y=800)

# --------------------------------------------------------------------------------------------------

#월드맵 프레임
worldmap_frame = tkinter.Frame(root)
canvas2 = tkinter.Canvas(worldmap_frame, width=1500, height=900)
canvas2.pack()

backgroundimg = tkinter.PhotoImage(file="worldmap.png") # 월드맵 이미지1
canvas2.create_image(0,0,anchor=tkinter.NW, image=backgroundimg) # 월드맵 이미지2

# 월드맵 프레임 버튼
b1 = tkinter.PhotoImage(file="stage1b.png")
stage1_button = tkinter.Button(worldmap_frame, image = b1, command=start_realgame, bd = 0, highlightthickness=0)
stage1_button.pack()
stage1_button.place(x=300,y=650)

# -----------------------------------------------------------------------------------------------------

# 게임 프레임
game_frame = tkinter.Frame(root)
canvas = tkinter.Canvas(game_frame, width=1500, height=900, bg="white")
canvas.pack()

game1_image = tkinter.PhotoImage(file="stage1.png")
canvas.create_image(0,0,anchor=tkinter.NW, image=game1_image)
switch_stage1()
# --------------------------------------------------------------------------------------------------------



# 캐릭터 이미지 로드
char_img = tkinter.PhotoImage(file="c1-3.png")
canvas.create_image(mx*30+15, my*30+15, image=char_img, tag="MYCHR")

# 게임 맵
maps = [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,1,1,1,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [0,0,0,1,1,0,0,0,0,0,1,1,0,0,0,0,0,0,0,1,1,1,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [0,0,0,0,1,1,1,0,0,0,0,1,1,0,0,0,0,0,1,1,0,1,0,0,1,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [0,0,0,0,0,0,1,1,0,0,0,0,1,1,1,1,1,1,1,0,0,1,0,0,1,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,1,0,0,0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,1,1,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,1,1,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,1],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,1],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,1],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0,1,1,0,0,0,0,0,1,1,1],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,1,0,0,0,1,1,0,1],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,1],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1]
]

inventory_frame = tkinter.Frame(root)

inventory_label = tkinter.Label(inventory_frame) 
inventory_label.pack()


            
root.mainloop()
